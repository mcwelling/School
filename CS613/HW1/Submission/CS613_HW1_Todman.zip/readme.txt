Readme file for HW1 Submission

Contents
--CS613_HW_Todman.pdf
	--Latex formatted PDF document containing answers to the HW questions
--HW_Q2_Q3.m
	--Matlab file containing scripts to generate viz for Q2 & Q3
--HW_Q4_Clustering.m
	--Matlab file containing scripts to generate viz for Q4
--k_2.gif
	--gif of kMeans where k=2
--k_3.gif
	--gif of kMeans where k=3
--k_5.gif
	--gif of kMeans where k=5

if you have any questions/concerns please email me at mht47@drexel.edu

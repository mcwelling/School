Readme file for HW2 Submission

Contents
--CS613_HW2_Todman.pdf
	--Latex formatted PDF document containing answers to the HW questions
--Q2.m
	--Closed for linear regression. No parameters to change. should meet spec.
--Q3.m
	--s-fold validation. The variable "partitions" controls the number of folds
	--change the second parameter in the object CVO in the outer for loop to switch 	between s-fold and holdout methodologies. see comments in code, as you will need
	to use hold out method to do number 4 in this problem.
--Q4.m
	--locally weighted regression. no params to change. should meet spec.
--Q5.m
	--gradient descent. should be agnostic to feature and observation counts.
	--no params to change. should meet spec.


if you have any questions/concerns please email me at mht47@drexel.edu
